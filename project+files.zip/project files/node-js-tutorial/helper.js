module.exports.user = function(data) {
    return `hello, my name is ${data}`;
}

module.exports.id = function(id) {
    return `${id}`
}

module.exports.email = function(email) {
    return `${email}`
}

